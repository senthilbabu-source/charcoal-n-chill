# SEO Implementation Checklist
**Charcoal N Chill Website - Priority Action Items**

---

## 🔴 WEEK 1: CRITICAL FIXES (Must Do First)

### Day 1-2: Image Optimization

- [ ] **Install and configure next.config.js**
  - Create file in project root
  - Add image optimization settings
  - Configure domains and formats
  
- [ ] **Convert Homepage Images**
  - [ ] Hero background image (`/app/page.tsx` line 34-38)
  - [ ] Menu preview images (3 items, lines 138-143)
  - [ ] All other homepage images
  
- [ ] **Convert Header/Footer Logos**
  - [ ] Header logo (`/components/layout/Header.tsx` line 76-84)
  - [ ] Mobile menu logo (line 122)
  - [ ] Footer logo (`/components/layout/Footer.tsx` line 13)

- [ ] **Update Alt Text - Homepage**
  - [ ] Hero image: "Luxurious hookah lounge interior..."
  - [ ] Chicken 65: "Authentic Chicken 65 appetizer..."
  - [ ] Butter Chicken: "Traditional Butter Chicken curry..."
  - [ ] Signature Hookah: "Premium hookah setup with exotic flavors..."

### Day 3-4: Analytics & Tracking

- [ ] **Set up Google Analytics 4**
  - [ ] Create GA4 property
  - [ ] Get measurement ID (G-XXXXXXXXXX)
  - [ ] Add to `.env.local`: `NEXT_PUBLIC_GA_ID=G-XXXXXXXXXX`
  - [ ] Test in Google Analytics real-time view
  
- [ ] **Set up Facebook Pixel**
  - [ ] Create Facebook Pixel
  - [ ] Get Pixel ID
  - [ ] Add to `.env.local`: `NEXT_PUBLIC_FACEBOOK_PIXEL_ID=XXXXXXX`
  - [ ] Test with Facebook Pixel Helper extension
  
- [ ] **Configure Event Tracking**
  - [ ] Phone number clicks
  - [ ] Reservation button clicks
  - [ ] Menu views
  - [ ] Location clicks
  - [ ] Social media follows

- [ ] **Google Search Console**
  - [ ] Verify property ownership
  - [ ] Submit sitemap: `https://www.charcoalnchill.com/sitemap.xml`
  - [ ] Request indexing for main pages

### Day 5-7: Critical Schema & Pages

- [ ] **Add Review Schema to Homepage**
  - [ ] Mark up the 4.8 rating display
  - [ ] Add customer testimonial schema
  
- [ ] **Create Legal Pages**
  - [ ] Privacy Policy page (`/app/privacy/page.tsx`)
  - [ ] Terms of Service page (`/app/terms/page.tsx`)
  - [ ] Cookie Policy page (`/app/cookies/page.tsx`)
  - [ ] Update footer links from `#` to actual URLs
  
- [ ] **Menu Schema Enhancement**
  - [ ] Add ALL menu items to schema (not just 2 appetizers)
  - [ ] Include prices, descriptions
  - [ ] Add dietary information where applicable

---

## 🟡 WEEK 2: HIGH PRIORITY

### Image Optimization - All Pages

- [ ] **About Page**
  - [ ] Convert atmosphere image (`/app/about/page.tsx`)
  - [ ] Update alt text with descriptive context
  
- [ ] **Menu Page**
  - [ ] Convert all food images
  - [ ] Add descriptive alt text for each dish
  - [ ] Include dietary info in alt text when relevant
  
- [ ] **Private Events Page**
  - [ ] Convert VIP section image
  - [ ] Convert event photos
  - [ ] Update all alt text
  
- [ ] **Events Page**
  - [ ] Convert event banners
  - [ ] Add descriptive alt text
  
- [ ] **Blog Page**
  - [ ] Convert blog post images
  - [ ] Ensure each post has unique alt text

### Content Enhancements

- [ ] **Homepage H1 Optimization**
  - [ ] Update H1 to include primary keywords
  - [ ] Keep brand name but add context
  - [ ] Test new version
  
- [ ] **FAQ Schema Implementation**
  - [ ] Verify FAQ schema is rendering
  - [ ] Test with Rich Results Test tool
  - [ ] Add more FAQs if needed:
    - [ ] "What are your most popular hookah flavors?"
    - [ ] "Do you take reservations for large groups?"
    - [ ] "Do you have parking?"
    - [ ] "Are you family-friendly?"

### First Blog Posts (SEO Optimized)

- [ ] **Blog Post 1: "Top 10 Hookah Flavors at Charcoal N Chill"**
  - [ ] 1000-1500 words
  - [ ] Include images with alt text
  - [ ] Add Article schema
  - [ ] Internal links to menu
  - [ ] Add FAQ section at bottom
  
- [ ] **Blog Post 2: "Guide to Indian Cuisine: Understanding Our Menu"**
  - [ ] Explain dishes, spices, flavors
  - [ ] Link to menu items
  - [ ] Include images of dishes
  - [ ] Add Article schema
  
- [ ] **Blog Post 3: "Planning Your Private Event in Alpharetta"**
  - [ ] Highlight VIP section
  - [ ] Mention capacity (60 guests)
  - [ ] Link to private events page
  - [ ] Add Event schema if applicable

---

## 🟡 WEEK 3-4: MEDIUM PRIORITY

### Performance Optimization

- [ ] **Font Optimization**
  - [ ] Add `display: 'swap'` to Raleway font config
  - [ ] Add `preload: true`
  - [ ] Test font loading performance
  
- [ ] **Lazy Loading Implementation**
  - [ ] Identify below-fold components
  - [ ] Implement dynamic imports for:
    - [ ] Blog section
    - [ ] Events gallery
    - [ ] Testimonials
    - [ ] Admin components
  
- [ ] **Code Splitting**
  - [ ] Review bundle size
  - [ ] Split large components
  - [ ] Optimize third-party libraries

### Schema Enhancements

- [ ] **Event Schema for Weekly Events**
  - [ ] Afrobeats Night
  - [ ] Latino Night
  - [ ] Bollywood Night
  - [ ] Belly Dancing Shows
  
- [ ] **Special Offers Schema**
  - [ ] Happy Hour specials
  - [ ] Promotional pricing
  - [ ] Seasonal offers
  
- [ ] **ImageObject Schema**
  - [ ] Add to all menu item images
  - [ ] Add to gallery images
  - [ ] Include relevant keywords in description

### Local SEO Enhancement

- [ ] **Location Pages (Optional)**
  - [ ] `/locations/johns-creek` - "Serving Johns Creek"
  - [ ] `/locations/roswell` - "Serving Roswell"  
  - [ ] `/locations/milton` - "Serving Milton"
  - [ ] `/locations/duluth` - "Serving Duluth"
  
- [ ] **Google Business Profile Optimization**
  - [ ] Complete all sections
  - [ ] Add photos (10+ high-quality images)
  - [ ] Post weekly updates
  - [ ] Respond to all reviews
  - [ ] Add menu items
  - [ ] Add special hours for holidays

---

## 🟢 MONTH 2: ONGOING OPTIMIZATION

### Content Strategy

- [ ] **Blog Content Calendar (2-4 posts/month)**
  - [ ] "Best Late Night Dining in North Atlanta"
  - [ ] "Hookah Etiquette: Beginner's Guide"
  - [ ] "Pairing Hookah Flavors with Indian Dishes"
  - [ ] "Behind the Scenes: How We Prepare Hookah"
  - [ ] "Weekend Events Calendar"
  - [ ] "Indian Street Food Explained"
  
- [ ] **Testimonials Page**
  - [ ] Create dedicated reviews page
  - [ ] Add Review schema for each testimonial
  - [ ] Include customer photos (with permission)
  - [ ] Embed Google Reviews widget
  - [ ] Add filter by category

### Link Building

- [ ] **Internal Linking**
  - [ ] Add contextual links in blog posts
  - [ ] Cross-link related content
  - [ ] Add "Related Articles" sections
  - [ ] Create anchor links for long pages
  
- [ ] **External Link Building**
  - [ ] Local business directories (Yelp, TripAdvisor)
  - [ ] Local Atlanta/Alpharetta blogs
  - [ ] Partnership opportunities
  - [ ] Guest posting on food blogs
  - [ ] Local event sponsorships

### Advanced SEO

- [ ] **Video Content**
  - [ ] Restaurant tour video
  - [ ] Hookah preparation tutorial
  - [ ] Cooking demonstrations
  - [ ] Event highlights
  - [ ] Add VideoObject schema for each
  
- [ ] **Rich Media**
  - [ ] Virtual tour (Google Street View)
  - [ ] 360° photos of interior
  - [ ] Menu PDF download
  - [ ] Downloadable event calendar

---

## TESTING & MONITORING

### Weekly Checks

- [ ] **Google Search Console**
  - [ ] Check for crawl errors
  - [ ] Monitor coverage issues
  - [ ] Review performance reports
  - [ ] Check mobile usability
  
- [ ] **Google Analytics**
  - [ ] Review traffic sources
  - [ ] Check bounce rates
  - [ ] Monitor conversion goals
  - [ ] Analyze user flow
  
- [ ] **PageSpeed Insights**
  - [ ] Test homepage
  - [ ] Test menu page
  - [ ] Monitor Core Web Vitals
  - [ ] Track improvements

### Monthly Reviews

- [ ] **Keyword Rankings**
  - [ ] Track primary keywords
  - [ ] Monitor local pack position
  - [ ] Check competitor rankings
  
- [ ] **Backlink Profile**
  - [ ] New backlinks acquired
  - [ ] Quality assessment
  - [ ] Disavow toxic links if needed
  
- [ ] **Content Performance**
  - [ ] Best performing blog posts
  - [ ] Update old content
  - [ ] Identify content gaps

---

## TOOLS NEEDED

### Free Tools
- [ ] Google Search Console
- [ ] Google Analytics 4
- [ ] Google PageSpeed Insights
- [ ] Google Rich Results Test
- [ ] Google Mobile-Friendly Test
- [ ] Schema Markup Validator
- [ ] Facebook Pixel Helper (Chrome extension)
- [ ] Lighthouse (Chrome DevTools)

### Recommended Paid Tools (Optional)
- [ ] Ahrefs or SEMrush (Keyword tracking, competitor analysis)
- [ ] Screaming Frog (Site crawling)
- [ ] Hotjar (Heatmaps, user behavior)

---

## QUICK WINS (Do These Today)

1. ✅ Add next.config.js file
2. ✅ Convert hero image to Next.js Image
3. ✅ Update 3-5 most important alt texts
4. ✅ Add Google Analytics ID to env file
5. ✅ Submit sitemap to Google Search Console

---

## SUCCESS METRICS

### 30 Days
- [ ] All images converted to Next.js Image
- [ ] PageSpeed score > 85 (mobile & desktop)
- [ ] Google Search Console showing no critical errors
- [ ] 3 blog posts published
- [ ] Privacy Policy & Terms live

### 60 Days
- [ ] Organic traffic increased by 20%+
- [ ] Local pack ranking top 5 for primary keywords
- [ ] 6-8 blog posts published
- [ ] 50+ quality backlinks acquired
- [ ] Core Web Vitals in "Good" range

### 90 Days
- [ ] Organic traffic increased by 40%+
- [ ] Local pack ranking top 3
- [ ] 10+ blog posts
- [ ] 100+ quality backlinks
- [ ] 5-star average rating (20+ reviews)

---

## NOTES

- Prioritize mobile experience (60%+ traffic is mobile)
- Focus on local keywords (Alpharetta, Johns Creek, etc.)
- Keep content fresh (update menu seasonally)
- Respond to ALL Google reviews within 24 hours
- Monitor competitors monthly
- Update schema when business info changes
- Test all changes on staging before production

---

**Last Updated:** January 10, 2026
**Next Review:** January 17, 2026

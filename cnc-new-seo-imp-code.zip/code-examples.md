# SEO Implementation Code Examples
**Specific code changes for Charcoal N Chill website**

---

## 1. Create next.config.js

Create this file in your **project root** (same level as `src/` folder):

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    // Modern image formats
    formats: ['image/webp', 'image/avif'],
    
    // Responsive breakpoints
    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
    
    // Cache images for 60 seconds
    minimumCacheTTL: 60,
    
    // Allowed image domains
    domains: ['www.charcoalnchill.com'],
    
    // Allow images from these domains without warning
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'www.charcoalnchill.com',
      },
    ],
  },
  
  // Enable gzip compression
  compress: true,
  
  // Optimize fonts automatically
  optimizeFonts: true,
  
  // Use SWC minifier (faster than Terser)
  swcMinify: true,
  
  // Generate standalone output for better performance
  output: 'standalone',
  
  // Strict mode for better error catching
  reactStrictMode: true,
  
  // Powered by header (can be removed for security)
  poweredByHeader: false,
}

module.exports = nextConfig
```

---

## 2. Update Environment Variables

Create or update `.env.local` in project root:

```bash
# Google Analytics 4
NEXT_PUBLIC_GA_ID=G-XXXXXXXXXX

# Facebook Pixel
NEXT_PUBLIC_FACEBOOK_PIXEL_ID=XXXXXXXXXXXXXXX

# Production URL
NEXT_PUBLIC_SITE_URL=https://www.charcoalnchill.com
```

**⚠️ Important:** Never commit this file to Git. Make sure `.env.local` is in your `.gitignore`.

---

## 3. Font Optimization

**File:** `/src/app/layout.tsx`

**BEFORE:**
```typescript
const raleway = Raleway({
  variable: "--font-raleway",
  subsets: ["latin"],
  weight: ["400", "700", "900"],
});
```

**AFTER:**
```typescript
const raleway = Raleway({
  variable: "--font-raleway",
  subsets: ["latin"],
  weight: ["400", "700", "900"],
  display: 'swap', // Prevent invisible text during font load
  preload: true,   // Preload font for faster rendering
});
```

---

## 4. Homepage Image Conversions

**File:** `/src/app/page.tsx`

### Hero Background Image

**BEFORE (Lines 32-40):**
```tsx
<div className="absolute inset-0 z-0">
  <img
    src="/images/hero-bg.jpg"
    className="w-full h-full object-cover scale-105"
    alt="Lounge background"
  />
  <div className="absolute inset-0 bg-black/70 backdrop-blur-[2px]" />
</div>
```

**AFTER:**
```tsx
import Image from 'next/image';

<div className="absolute inset-0 z-0">
  <Image
    src="/images/hero-bg.jpg"
    alt="Luxurious premium hookah lounge interior featuring Versace couches and ambient lighting at Charcoal N Chill in Alpharetta"
    fill
    priority // Load this image immediately (it's above the fold)
    quality={85}
    sizes="100vw"
    className="object-cover scale-105"
  />
  <div className="absolute inset-0 bg-black/70 backdrop-blur-[2px]" />
</div>
```

### Menu Preview Images

**BEFORE (Lines 138-143):**
```tsx
<div className="group relative overflow-hidden rounded-2xl aspect-[4/5]">
  <img
    src={item.image}
    alt={item.title}
    className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
  />
  {/* ... */}
</div>
```

**AFTER:**
```tsx
import Image from 'next/image';

<div className="group relative overflow-hidden rounded-2xl aspect-[4/5]">
  <Image
    src={item.image}
    alt={`Authentic ${item.title} - ${item.category} served at Charcoal N Chill Indian Restaurant`}
    fill
    quality={85}
    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
    className="object-cover transition-transform duration-500 group-hover:scale-110"
  />
  {/* ... */}
</div>
```

---

## 5. Header Logo Optimization

**File:** `/src/components/layout/Header.tsx`

**BEFORE (Lines 73-84):**
```tsx
<Link href="/" className="relative z-10 flex-shrink-0 group">
  <div className="absolute inset-0 bg-gold/20 blur-2xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
  <img
    src="/logo.png"
    alt="Charcoal N Chill - Premium Hookah & Indian Restaurant"
    className={cn(
      "transition-all duration-500 relative z-10",
      scrolled ? "h-14 md:h-16" : "h-20 md:h-24"
    )}
  />
</Link>
```

**AFTER:**
```tsx
import Image from 'next/image';

<Link href="/" className="relative z-10 flex-shrink-0 group">
  <div className="absolute inset-0 bg-gold/20 blur-2xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
  <div className={cn(
    "relative transition-all duration-500",
    scrolled ? "h-14 md:h-16 w-14 md:w-16" : "h-20 md:h-24 w-20 md:w-24"
  )}>
    <Image
      src="/logo.png"
      alt="Charcoal N Chill - Premium Hookah Lounge & Authentic Indian Restaurant in Alpharetta, Georgia"
      fill
      priority
      className="object-contain"
      sizes="(max-width: 768px) 64px, 96px"
    />
  </div>
</Link>
```

**Mobile Menu Logo (Line 122):**

**BEFORE:**
```tsx
<img src="/logo.png" alt="Charcoal N Chill" className="h-20" />
```

**AFTER:**
```tsx
<div className="relative h-20 w-20">
  <Image
    src="/logo.png"
    alt="Charcoal N Chill"
    fill
    className="object-contain"
  />
</div>
```

---

## 6. Footer Logo Optimization

**File:** `/src/components/layout/Footer.tsx`

**BEFORE (Line 13):**
```tsx
<img src="/logo.png" alt="Charcoal N Chill" className="h-16 md:h-20 relative z-10" />
```

**AFTER:**
```tsx
import Image from 'next/image';

<div className="relative h-16 md:h-20 w-16 md:w-20">
  <Image
    src="/logo.png"
    alt="Charcoal N Chill - Alpharetta's Premier Hookah Lounge"
    fill
    className="object-contain relative z-10"
    sizes="80px"
  />
</div>
```

---

## 7. About Page Image

**File:** `/src/app/about/page.tsx`

**BEFORE (Lines 46-52):**
```tsx
<div className="relative aspect-square md:aspect-video rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
  <img
    src="/images/lounge-atmosphere.jpg"
    alt="Charcoal N Chill Atmosphere"
    className="w-full h-full object-cover"
  />
  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
</div>
```

**AFTER:**
```tsx
import Image from 'next/image';

<div className="relative aspect-square md:aspect-video rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
  <Image
    src="/images/lounge-atmosphere.jpg"
    alt="Sophisticated lounge atmosphere at Charcoal N Chill featuring luxury Versace seating, ambient lighting, and modern hookah setup"
    fill
    quality={85}
    sizes="(max-width: 768px) 100vw, 50vw"
    className="object-cover"
  />
  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
</div>
```

---

## 8. Enhanced H1 Tag (Homepage)

**File:** `/src/app/page.tsx`

**BEFORE (Lines 43-46):**
```tsx
<h1 className="text-6xl md:text-8xl lg:text-9xl font-heading font-black text-white uppercase tracking-tighter leading-none mb-4 animate-float">
  <span className="neon-text-gold">Charcoal</span> <br />
  <span className="text-gold neon-text-gold">&</span> Chill
</h1>
```

**AFTER:**
```tsx
<h1 className="text-6xl md:text-8xl lg:text-9xl font-heading font-black text-white uppercase tracking-tighter leading-none mb-4 animate-float">
  <span className="neon-text-gold">Charcoal N Chill</span>
  <span className="block text-2xl md:text-3xl lg:text-4xl mt-4 font-normal normal-case tracking-normal text-gray-200">
    Premium Hookah Lounge & Authentic Indian Restaurant in Alpharetta
  </span>
</h1>
```

---

## 9. Add Review Schema (Homepage)

**File:** `/src/app/page.tsx`

Add this after line 21 (after restaurant schema):

```tsx
<JsonLd data={{
  "@context": "https://schema.org",
  "@type": "Review",
  "itemReviewed": {
    "@type": "Restaurant",
    "name": "Charcoal N Chill"
  },
  "reviewRating": {
    "@type": "Rating",
    "ratingValue": "4.8",
    "bestRating": "5",
    "worstRating": "1"
  },
  "author": {
    "@type": "Person",
    "name": "Verified Customer"
  },
  "reviewBody": "The best hookah lounge in North Atlanta. The food is authentic and the vibe is unmatched. Highly recommend the Butter Chicken and their signature mint hookah!",
  "datePublished": "2026-01-01"
}} id="review-schema" />
```

---

## 10. Complete Menu Schema

**File:** `/src/app/menu/page.tsx`

**BEFORE (Lines 17-32) - Only shows 2 items:**
```tsx
const menuSchema = {
  "@context": "https://schema.org",
  "@type": "Menu",
  "name": "Charcoal N Chill Menu",
  "description": "Authentic Indian cuisine, 50+ hookah flavors, craft cocktails",
  "hasMenuSection": [
    {
      "@type": "MenuSection",
      "name": "Appetizers",
      "hasMenuItem": [
        { "@type": "MenuItem", "name": "Chicken 65", "description": "South Indian spicy fried chicken", "offers": { "@type": "Offer", "price": "11.00", "priceCurrency": "USD" } },
        { "@type": "MenuItem", "name": "Paneer 65", "description": "Spicy deep-fried cottage cheese cubes", "offers": { "@type": "Offer", "price": "10.00", "priceCurrency": "USD" } }
      ]
    }
  ]
};
```

**AFTER - Include ALL menu items:**
```tsx
const menuSchema = {
  "@context": "https://schema.org",
  "@type": "Menu",
  "name": "Charcoal N Chill Menu",
  "description": "Authentic Indian cuisine, 50+ hookah flavors, craft cocktails",
  "hasMenuSection": [
    {
      "@type": "MenuSection",
      "name": "Appetizers",
      "hasMenuItem": [
        { 
          "@type": "MenuItem", 
          "name": "Chicken 65", 
          "description": "South Indian spicy fried chicken", 
          "offers": { "@type": "Offer", "price": "11.00", "priceCurrency": "USD" },
          "suitableForDiet": "GlutenFreeDiet"
        },
        { 
          "@type": "MenuItem", 
          "name": "Paneer 65", 
          "description": "Spicy deep-fried cottage cheese cubes", 
          "offers": { "@type": "Offer", "price": "10.00", "priceCurrency": "USD" },
          "suitableForDiet": "VegetarianDiet"
        },
        { 
          "@type": "MenuItem", 
          "name": "Chicken Tenders", 
          "description": "Crispy golden tenders with choice of dipping sauce", 
          "offers": { "@type": "Offer", "price": "8.00", "priceCurrency": "USD" }
        },
        { 
          "@type": "MenuItem", 
          "name": "Veg Spring Rolls", 
          "description": "Fresh vegetables wrapped and fried to perfection", 
          "offers": { "@type": "Offer", "price": "7.00", "priceCurrency": "USD" },
          "suitableForDiet": "VegetarianDiet"
        },
        // Add ALL other appetizers...
      ]
    },
    {
      "@type": "MenuSection",
      "name": "Entrees",
      "hasMenuItem": [
        { 
          "@type": "MenuItem", 
          "name": "Butter Chicken", 
          "description": "Tender chicken in creamy tomato-based sauce", 
          "offers": { "@type": "Offer", "price": "16.00", "priceCurrency": "USD" },
          "suitableForDiet": "GlutenFreeDiet"
        },
        // Add ALL entrees...
      ]
    },
    {
      "@type": "MenuSection",
      "name": "Hookah",
      "hasMenuItem": [
        { 
          "@type": "MenuItem", 
          "name": "Premium Hookah", 
          "description": "Choice of 50+ flavors prepared by expert hookah masters", 
          "offers": { "@type": "Offer", "price": "35.00", "priceCurrency": "USD" }
        },
        // Add hookah options...
      ]
    }
  ]
};
```

---

## 11. Create Privacy Policy Page

**Create new file:** `/src/app/privacy/page.tsx`

```tsx
import { constructMetadata } from "@/lib/metadata";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Section } from "@/components/ui/Section";

export const metadata = constructMetadata({
  title: "Privacy Policy",
  description: "Privacy Policy for Charcoal N Chill - How we collect, use, and protect your information",
  path: "/privacy",
});

export default function PrivacyPage() {
  return (
    <>
      <Header />
      <main className="pt-20">
        <Section className="py-24">
          <div className="max-w-4xl mx-auto prose prose-invert">
            <h1 className="text-5xl font-heading font-black text-white mb-8">Privacy Policy</h1>
            <p className="text-gray-400 mb-8">Last updated: January 10, 2026</p>
            
            <h2 className="text-3xl font-bold text-white mt-12 mb-4">Information We Collect</h2>
            <p className="text-gray-400">
              At Charcoal N Chill, we collect information you provide directly to us when you:
            </p>
            <ul className="text-gray-400">
              <li>Make a reservation</li>
              <li>Sign up for our newsletter</li>
              <li>Contact us with inquiries</li>
              <li>Visit our website</li>
            </ul>

            <h2 className="text-3xl font-bold text-white mt-12 mb-4">How We Use Your Information</h2>
            <p className="text-gray-400">
              We use the information we collect to:
            </p>
            <ul className="text-gray-400">
              <li>Process and confirm your reservations</li>
              <li>Respond to your inquiries and provide customer service</li>
              <li>Send you updates about events and special offers (with your consent)</li>
              <li>Improve our website and services</li>
            </ul>

            <h2 className="text-3xl font-bold text-white mt-12 mb-4">Information Sharing</h2>
            <p className="text-gray-400">
              We do not sell, trade, or rent your personal information to third parties. 
              We may share your information with trusted service providers who assist us 
              in operating our website and conducting our business.
            </p>

            <h2 className="text-3xl font-bold text-white mt-12 mb-4">Cookies</h2>
            <p className="text-gray-400">
              We use cookies and similar tracking technologies to enhance your experience 
              on our website. You can control cookies through your browser settings.
            </p>

            <h2 className="text-3xl font-bold text-white mt-12 mb-4">Contact Us</h2>
            <p className="text-gray-400">
              If you have any questions about this Privacy Policy, please contact us at:
            </p>
            <p className="text-gray-400">
              Email: charcoalnchill@gmail.com<br />
              Phone: (470) 546-4866<br />
              Address: 11950 Jones Bridge Rd Ste 103, Alpharetta, GA 30005
            </p>
          </div>
        </Section>
      </main>
      <Footer />
    </>
  );
}
```

---

## 12. Create Terms of Service Page

**Create new file:** `/src/app/terms/page.tsx`

```tsx
import { constructMetadata } from "@/lib/metadata";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Section } from "@/components/ui/Section";

export const metadata = constructMetadata({
  title: "Terms of Service",
  description: "Terms of Service for Charcoal N Chill - Rules and regulations for using our services",
  path: "/terms",
});

export default function TermsPage() {
  return (
    <>
      <Header />
      <main className="pt-20">
        <Section className="py-24">
          <div className="max-w-4xl mx-auto prose prose-invert">
            <h1 className="text-5xl font-heading font-black text-white mb-8">Terms of Service</h1>
            <p className="text-gray-400 mb-8">Last updated: January 10, 2026</p>
            
            <h2 className="text-3xl font-bold text-white mt-12 mb-4">Acceptance of Terms</h2>
            <p className="text-gray-400">
              By accessing and using Charcoal N Chill's website and services, you accept 
              and agree to be bound by these Terms of Service.
            </p>

            <h2 className="text-3xl font-bold text-white mt-12 mb-4">Age Requirement</h2>
            <p className="text-gray-400">
              You must be at least 21 years old to use our hookah services. Valid ID 
              will be required upon entry.
            </p>

            <h2 className="text-3xl font-bold text-white mt-12 mb-4">Reservations</h2>
            <p className="text-gray-400">
              Reservations are subject to availability. We reserve the right to cancel 
              or modify reservations as necessary. A credit card may be required to hold 
              certain reservations.
            </p>

            <h2 className="text-3xl font-bold text-white mt-12 mb-4">Conduct</h2>
            <p className="text-gray-400">
              We reserve the right to refuse service to anyone who:
            </p>
            <ul className="text-gray-400">
              <li>Is visibly intoxicated</li>
              <li>Engages in disruptive or inappropriate behavior</li>
              <li>Fails to comply with establishment rules</li>
              <li>Is under the legal age for hookah service</li>
            </ul>

            <h2 className="text-3xl font-bold text-white mt-12 mb-4">Limitation of Liability</h2>
            <p className="text-gray-400">
              Charcoal N Chill is not liable for any injuries or damages that may occur 
              on our premises, except where required by law.
            </p>

            <h2 className="text-3xl font-bold text-white mt-12 mb-4">Contact Information</h2>
            <p className="text-gray-400">
              For questions about these Terms of Service:<br />
              Email: charcoalnchill@gmail.com<br />
              Phone: (470) 546-4866
            </p>
          </div>
        </Section>
      </main>
      <Footer />
    </>
  );
}
```

---

## 13. Update Footer Links

**File:** `/src/components/layout/Footer.tsx`

**BEFORE (Lines 100-105):**
```tsx
{["Privacy Policy", "Terms of Service", "Cookies"].map((item) => (
  <Link key={item} href="#" className="...">
    {item}
  </Link>
))}
```

**AFTER:**
```tsx
<Link href="/privacy" className="text-xs text-gray-500 hover:text-gold uppercase tracking-widest transition-colors font-bold">
  Privacy Policy
</Link>
<Link href="/terms" className="text-xs text-gray-500 hover:text-gold uppercase tracking-widest transition-colors font-bold">
  Terms of Service
</Link>
<Link href="/cookies" className="text-xs text-gray-500 hover:text-gold uppercase tracking-widest transition-colors font-bold">
  Cookies
</Link>
```

---

## 14. Event Schema (for Events Page)

**File:** `/src/app/events/page.tsx`

Add this schema for each recurring event:

```tsx
const afrobeatsNightSchema = {
  "@context": "https://schema.org",
  "@type": "Event",
  "name": "Afrobeats Night at Charcoal N Chill",
  "description": "Join us for an electrifying night of Afrobeats music, premium hookah, and authentic Indian cuisine",
  "image": "https://www.charcoalnchill.com/images/afrobeats-night.jpg",
  "startDate": "2026-01-17T21:00:00-05:00",
  "endDate": "2026-01-18T02:00:00-05:00",
  "eventStatus": "https://schema.org/EventScheduled",
  "eventAttendanceMode": "https://schema.org/OfflineEventAttendanceMode",
  "location": {
    "@type": "Place",
    "name": "Charcoal N Chill",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "11950 Jones Bridge Rd Ste 103",
      "addressLocality": "Alpharetta",
      "addressRegion": "GA",
      "postalCode": "30005",
      "addressCountry": "US"
    }
  },
  "organizer": {
    "@type": "Organization",
    "name": "Charcoal N Chill",
    "url": "https://www.charcoalnchill.com"
  },
  "offers": {
    "@type": "Offer",
    "url": "https://www.charcoalnchill.com/events",
    "price": "0",
    "priceCurrency": "USD",
    "availability": "https://schema.org/InStock",
    "validFrom": "2026-01-10"
  },
  "performer": {
    "@type": "MusicGroup",
    "name": "DJ Afrobeats"
  }
};
```

---

## 15. Lazy Loading Components

**File:** `/src/app/page.tsx`

Add at the top of the file:

```tsx
import dynamic from 'next/dynamic';

// Lazy load below-fold components
const MenuPreview = dynamic(() => import('@/components/home/MenuPreview'), {
  loading: () => <div className="h-96 bg-charcoal animate-pulse" />
});

const LocationMap = dynamic(() => import('@/components/home/LocationMap'), {
  loading: () => <div className="h-96 bg-charcoal animate-pulse" />
});
```

Then use these components instead of inline code.

---

## 16. Event Tracking Implementation

**File:** `/src/components/layout/Analytics.tsx`

Already have the trackEvent function, now use it:

**Example usage in components:**

```tsx
import { trackEvent } from '@/components/layout/Analytics';

// In your CTA buttons:
<Button 
  onClick={() => {
    trackEvent('reservation_click', {
      location: 'homepage_hero',
      value: 1
    });
  }}
>
  Reserve Table
</Button>

// Track phone clicks:
<a 
  href="tel:4705464866"
  onClick={() => {
    trackEvent('phone_click', {
      location: 'footer'
    });
  }}
>
  (470) 546-4866
</a>

// Track menu views:
<Link
  href="/menu"
  onClick={() => {
    trackEvent('menu_view', {
      source: 'homepage_cta'
    });
  }}
>
  View Menu
</Link>
```

---

## Testing Checklist

After implementing changes:

1. **Image Optimization**
   ```bash
   npm run build
   npm run start
   # Check that images are loading as WebP
   # Open DevTools → Network → Img filter
   ```

2. **Schema Validation**
   - Test at: https://validator.schema.org/
   - Test Rich Results: https://search.google.com/test/rich-results
   - Paste your page URL or HTML

3. **Performance Testing**
   - PageSpeed Insights: https://pagespeed.web.dev/
   - Target: 85+ on mobile and desktop

4. **Analytics Verification**
   - Google Analytics: Real-time → Overview (should see visitors)
   - Facebook Pixel: Use Pixel Helper Chrome extension

5. **Mobile Testing**
   - Google Mobile-Friendly Test: https://search.google.com/test/mobile-friendly
   - Test on actual devices

---

## Deployment Notes

1. Update environment variables on your hosting platform (Vercel, Netlify, etc.)
2. Clear cache after deployment
3. Submit updated sitemap to Google Search Console
4. Monitor for any build errors
5. Test all functionality on production

---

**Questions?**
Review the full audit report for context on why each change is important.
